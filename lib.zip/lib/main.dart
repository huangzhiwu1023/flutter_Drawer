import 'package:flutter/material.dart';

import 'dragBottomSheet/drawer_container.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);
  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;

  void _incrementCounter() {
    setState(() {
      _counter++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'You have pushed the button this many times:',
            ),
            Text(
              '$_counter',
              style: Theme.of(context).textTheme.headline4,
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: (){



          //就一行代码（这个方法，如果有需要还可以放开，目前就放出了3个主要：子类组件、最小高度、最大高度），
          // 因为大家每个人的需求场景都不一样，就没高度封装了，主要扩展性差，希望能帮到大家;
          showDrawer(context,childWidget(),260,460);//如果用了请给颗星，不能就不要用了(不要白嫖)



        },
        child: Icon(Icons.add),
      ),
    );
  }
  //要加载的组件
  Widget childWidget() {
    return Container(width: MediaQuery.of(context).size.width,height: 460,color: Colors.grey,);
  }



}
